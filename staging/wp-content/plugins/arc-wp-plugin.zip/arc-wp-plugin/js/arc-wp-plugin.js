console.log('pages',pages);

//document.addEventListener('DOMContentLoaded', (event) => {
  //the event occurred
  //document.querySelectorAll("[data-foo='1']")
    $=jQuery;
    
    $( document ).ready(function() {
        console.log( "ready!" );
        let divs = document.querySelectorAll('.error *')

        divs.forEach((item)=>{
            let content = item.innerHTML
            let regex = /CleanTalk/im
            if(regex.test(content)){
                item.remove();
            }
        })
    });

  
    // for (let x = 0; x < divs.length; x++) {
    // 	let div = divs[x];
    // 	let content = div.innerHTML.trim();
        
    //     console.log('content',content)
    // 	if (regex.test(content)) {
    //   	div.style.display = 'none';
    //   }
    //}
//})
